package com.grasim.IndogulfAPI.model;

public enum WebAPIResponseType {

	LIST,OBJECT,EMPTY;
}
