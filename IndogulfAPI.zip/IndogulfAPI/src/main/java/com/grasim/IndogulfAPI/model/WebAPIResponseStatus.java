package com.grasim.IndogulfAPI.model;

public enum WebAPIResponseStatus {

	SUCCESS, FAIL;
}
